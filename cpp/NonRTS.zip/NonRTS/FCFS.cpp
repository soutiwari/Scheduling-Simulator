#include<bits/stdc++.h>
using namespace std;
struct process
{
    int arrival,pno,execution;
    int start;
    int end;
};
int main(int arg,char* argv[])
{
    char *filename;
    if(arg>1)
    {
        filename = argv[1];
        //cout<<filename;
    }
    else{
        cout<<"No Input";
        exit(1);
    }

    fstream file;

    file.open(filename,ios::in | ios::out);

    int n;
    file>>n;

    process p[n];
    for(int i=0;i<n;i++)
    {
        p[i].pno = i+1;
        file>>p[i].arrival;
        file>>p[i].execution;
        //cin>>p[i].pno>>p[i].arrival>>p[i].execution;
    }
    p[0].start=p[0].arrival;
    p[0].end = p[0].arrival+p[0].execution;
    //cout<<p[0].start<<" "<<p[0].end<<endl;
    int clock=p[0].end;
    for(int i=1;i<n;i++)
    {
        if(clock<p[i].arrival)
        {
            clock=p[i].arrival;
        }
        p[i].start=clock;
        p[i].end=clock+p[i].execution;
        clock=p[i].end;
    }
    for(int i=0;i<n;i++)
    {
        cout<<p[i].pno<<" "<<p[i].start<<" "<<p[i].end<<endl;
    }
}
