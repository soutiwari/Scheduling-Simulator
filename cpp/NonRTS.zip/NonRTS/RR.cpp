#include<bits/stdc++.h>
#include<fstream>
using namespace std;
int main(int arg, char* argv[])
{
    char *filename;
    if(arg>1)
    {
        filename = argv[1];
        //cout<<filename;
    }
    else{
        cout<<"no input";
        exit(1);
    }

    fstream file;

    file.open(filename,ios::in | ios::out);


  int i,j,n,time,remain,flag=0,ts;
  int sum_wait=0,sum_turnaround=0;
  //printf("Enter no of Processes : ");
  //scanf("%d",&n);
    file>>n;
    file>>ts;
  remain=n;
  int at[n],bt[n],rt[n];
  int clock[2000];
  for(i=0;i<n;i++)
  {
    //printf("Enter arrival time and burst time for Process P%d :",i+1);
    //scanf("%d",&at[i]);
    file>>at[i];
    //scanf("%d",&bt[i]);
    file>>bt[i];
    rt[i]=bt[i];
  }
  //printf("Enter time slice");
  //scanf("%d",&ts);

  for(time=0,i=0;remain!=0;)
  {
    if(rt[i]<=ts && rt[i]>0)
    {
    cout<<i+1<<"  time-start-"<<time<<" ";
      time+=rt[i];
      rt[i]=0;
      flag=1;
        cout<<"time-end-"<<time<<endl;
    }
    else if(rt[i]>0)
    {
    cout<<i+1<<"  time-start-"<<time<<" ";
      rt[i]-=ts;
      time+=ts;
      cout<<"time-end-"<<time<<endl;
    }
    if(rt[i]==0 && flag==1)
    {
      remain--;
      flag=0;
    }
    if(i==n-1)
      i=0;
    else if(at[i+1]<=time)
      i++;
    else
    {
        for(int j=0;j<=i;j++)
        {
            if(rt[j]!=0)
            i=j;
            else
            time=at[i+1];
        }
    }
  }
  return 0;
}


